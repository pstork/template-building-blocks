# Description

This resource will provision a site collection to the current farm, based on
the settings that are passed through. These settings map to the New-SPSite
cmdlet and accept the same values and types.

The current version of SharePointDsc is only able to check for the existence
of a site collection, the additional parameters are not checked for yet, but
will be in a later release
