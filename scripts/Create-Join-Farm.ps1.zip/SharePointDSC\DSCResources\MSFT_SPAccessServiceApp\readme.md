# Description

This resource is responsible for creating Access Services Application instances
within the local SharePoint farm. The resource will provision and configure the
Access Services Service Application.
