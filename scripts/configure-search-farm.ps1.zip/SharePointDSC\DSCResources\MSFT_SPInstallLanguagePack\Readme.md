# Description

This resource is used to install the SharePoint Language Pack binaries. The
BinaryDir parameter should point to the path that setup.exe is located (not to
setup.exe itself). The BinaryInstallDays and BinaryInstallTime parameters
specify a window in which the update can be installed. This module depends on
